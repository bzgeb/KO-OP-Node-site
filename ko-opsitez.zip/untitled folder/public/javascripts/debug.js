$("#debug").click(function() {alert($("#debug").width())});
